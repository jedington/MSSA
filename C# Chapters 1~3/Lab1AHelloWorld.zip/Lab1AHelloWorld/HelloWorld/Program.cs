﻿using System;

namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine();
            Console.WriteLine("Hello World!");
            // Console.Beep();
            Console.WriteLine("Today\tis\tWednesday");
            Console.Write("Bonjour   \n");
            Console.WriteLine("Monde!");
        }
    }
}
