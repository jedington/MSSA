﻿using System;

namespace MSSA.CS.Welcome
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Julian Edington\nWelcome to C#!");
        }
    }
}
