﻿using System;

namespace Ch3Lab
{
    class Program
    {
        static void Main(string[] args)
        {
            double circle1Radius = 1.0;
            double circle1Area = GetArea(circle1Radius); // 3.14159...
            double circle1Perimeter = GetPerimeter(circle1Radius); // 6.28318...
            Console.WriteLine("Circle 1      Area: " + circle1Area);
            Console.WriteLine("Circle 1 Perimeter: " + circle1Perimeter);
            Console.WriteLine();

            double rectangleLength = 2.0;
            double rectangleWidth = 3.0;
            double rectangleArea = GetArea(rectangleLength, rectangleWidth);
            double rectanglePerimeter = GetPerimeter(rectangleLength, rectangleWidth);
            Console.WriteLine("Rectangle      Area: {0}", rectangleArea);
            Console.WriteLine("Rectangle Perimeter: {0}", rectanglePerimeter);
            Console.WriteLine();

            double triangleSideA = 4.0;
            double triangleSideB = 5.0;
            double triangleSideC = 6.0;
            double triangleArea = GetArea(triangleSideA, triangleSideB, triangleSideC);
            double trianglePerimeter = GetPerimeter(triangleSideA, triangleSideB, triangleSideC);
            Console.WriteLine($"Triangle      Area: {triangleArea}");
            Console.WriteLine($"Triangle Perimeter: {trianglePerimeter}");
            Console.WriteLine();

            (circle1Area, circle1Perimeter) = GetAreaAndPerimeter(1.0);
            Console.WriteLine($"Circle 1      Area: {circle1Area}");
            Console.WriteLine($"Circle 1 Perimeter: {circle1Perimeter}");
            Console.WriteLine();

            (rectangleArea, rectanglePerimeter) = GetAreaAndPerimeter2(2.0, 3.0);
            Console.WriteLine($"Rectangle 1      Area: {rectangleArea}");
            Console.WriteLine($"Rectangle 1 Perimeter: {rectanglePerimeter}");
            Console.WriteLine();

            (triangleArea, trianglePerimeter) = GetAreaAndPerimeter3(4.0,5.0,6.0);
            Console.WriteLine($"Triangle 1      Area: {triangleArea}");
            Console.WriteLine($"Triangle 1 Perimeter: {trianglePerimeter}");
            Console.WriteLine();
        } // Main method ends


        static double GetArea(double radius) // Circle
            // {double area = Math.PI * radius * radius;
            // return area;}
            => Math.PI* radius *radius;
        // GetArea (Circle) method ends

        static double GetArea(double length, double width) // Rectangle
            // {double area = length * width;
            // return area;}
            =>  length * width;
        // GetArea (Rectangle) method ends

        static double GetArea(double a, double b, double c) // Triangle
            // {double s = (a + b + c)/2;
            // double area = Math.Sqrt(s * (s - a) * (s - b) * (s - c));
            // return area;}
            => Math.Sqrt(((a + b + c) / 2) * 
                        (((a + b + c) / 2) - a) * 
                        (((a + b + c) / 2) - b) * 
                        (((a + b + c) / 2) - c));
        // GetArea (Triangle) method ends


        static double GetPerimeter(double radius) // Circle
            // {double perimeter = 2 * Math.PI * radius;
            // return perimeter;}
            => 2 * Math.PI* radius;
        // GetPerimeter (Circle) method ends

        static double GetPerimeter(double length, double width) // Rectangle
            // {double perimeter =  (2 * length) + (2 * width);
            // return perimeter;}
            => (2 * length) + (2 * width);
        // GetPerimeter (Rectangle) method ends

        static double GetPerimeter(double a, double b, double c) // Triangle
            // {double perimeter = a + b + c;
            // return perimeter;}
            => a + b + c;
        // GetPerimeter (Triangle) method ends


        static (double area, double perimeter) GetAreaAndPerimeter(double radius) // Circle
        {
            double area = GetArea(radius);
            double perimeter = GetPerimeter(radius);
            return (area, perimeter);
        } // GetAreaAndPerimeter (Circle) ends

        static (double area, double perimeter) GetAreaAndPerimeter2(double length, double width) // Rectangle
        {
            double area = GetArea(length, width);
            double perimeter = GetPerimeter(length, width);
            return (area, perimeter);
        } // GetAreaAndPerimeter (Rectangle) ends

        static (double area, double perimeter) GetAreaAndPerimeter3(double a, double b, double c) // Triangle
        {
            // double s = (a + b + c)/2;
            // double area = Math.Sqrt(s * (s - a) * (s - b) * (s - c));
            double area = GetArea(a, b, c);
            double perimeter = GetPerimeter(a, b, c);
            return (area, perimeter);
        } // GetAreaAndPerimeter (Triangle) ends
    }
}
