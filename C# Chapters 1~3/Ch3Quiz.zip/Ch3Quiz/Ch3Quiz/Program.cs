﻿using System;

namespace MSSA.Ch3Quiz
{
    class Program
    {
        public static void Main(string[] args)
        {
            Vacation();
            Vacation("Florence, Italy");
            Console.Write($"\n{Add(30, 20)}");
            Console.Write($"\n{Divide(30, 20)}");
            Console.Write($"\n{Area(30,20)}\n");
        }

        // A1
        static void Vacation()
            => Console.WriteLine("My favorite vacation spot is Florence, Italy.");
        // Vacation (1st) method ends

        // A2
        static void Vacation(string vacationSpot)
            => Console.WriteLine($"My favorite vacation spot is {vacationSpot}.");
        // Vacation (2nd) method ends

        // A3
        static int Add(int firstNum, int secondNum)
            => (firstNum + secondNum); // aware parenthesis isn't necessary, just preference
        // Add method ends
        
        // A4
        static (int division, int remainder) Divide(int firstNum, int secondNum)
            => ((firstNum / secondNum), (firstNum % secondNum));
        // Divide method ends

        // A5
        static double Area(double length, double width = 10)
            => length * width; // aware parenthesis isn't necessary, just preference
        // Area method ends
        // Mind the Gap...
    } // class ends
} // namespace ends