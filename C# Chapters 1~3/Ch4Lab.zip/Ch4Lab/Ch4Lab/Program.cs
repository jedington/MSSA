﻿using System;
using System.Net.Http.Headers;
using System.Runtime.ExceptionServices;
using System.Transactions;

namespace MSSA.Simple.Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Input first number: ");
            double firstNumber = Convert.ToDouble(Console.ReadLine());

            Console.Write("Input second number: ");
            double secondNumber = Convert.ToDouble(Console.ReadLine());

            Console.Write("What operation to perform? (Acceptable inputs, not case-sensitive: add, sub, mul, div, mod): ");
            string operation = Console.ReadLine();
                
            operation = operation.ToLower();
            if (operation == "+" || operation == "add") // first: if
            {
                Console.WriteLine(firstNumber + secondNumber);
            }
            else if (operation == "-" || operation == "sub")
            {
                Console.WriteLine(firstNumber - secondNumber);
            }
            else if (operation == "*" || operation == "mul")
            {
                Console.WriteLine(firstNumber - secondNumber);
            }
            else if (operation == "/" || operation == "div")
            {
                Console.WriteLine(firstNumber - secondNumber);
            }
            else if (operation == "%" || operation == "mod")
            {
                Console.WriteLine(firstNumber % secondNumber);
            }
            else
            {
                Console.WriteLine("Error, wrong operation input...");
            } // if ends

            // switch (operation.ToUpper()) // alt: switch
            // { 
            //     case "ADD":
            //     case "+":
            //         double addition = firstNumber + secondNumber;
            //         Console.WriteLine($"{firstNumber} + {secondNumber} = {addition}");
            //         break;
            //     case "SUB":
            //     case "-":
            //         double subtraction = firstNumber - secondNumber;
            //         Console.WriteLine($"{firstNumber} - {secondNumber} = {subtraction}");
            //         break;
            //     case "MUL":
            //     case "*":
            //         double multiplication = firstNumber * secondNumber;
            //         Console.WriteLine($"{firstNumber} * {secondNumber} = {multiplication}");
            //         break;
            //     case "DIV":
            //     case "/":
            //         double division = firstNumber / secondNumber;
            //         Console.WriteLine($"{firstNumber} / {secondNumber} = {division}");
            //         break;
            //     case "MOD":
            //     case "%":
            //         double modulus = firstNumber % secondNumber;
            //         Console.WriteLine($"{firstNumber} % {secondNumber} = {modulus}");
            //         break;
            //     default:
            //         Console.WriteLine("Error, wrong operation input... Acceptable inputs are: add, sub, mul, div, mod.");
            //         break;
            // } // switch ends
        } // Main method ends
    } // class ends
} // namespace ends
