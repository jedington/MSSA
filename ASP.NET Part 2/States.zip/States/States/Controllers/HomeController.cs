﻿using Microsoft.AspNetCore.Mvc;
using States.Models;

namespace States.Controllers
{
    public class HomeController : Controller
    {
        //   F i e l d s   &   P r o p e r t i e s
        private IStateRepository _repository;
        
        
        //   C o n s t r u c t o r s
        public HomeController(IStateRepository repository)
            => _repository = repository;
        // HomeController const ends


        //   M e t h o d s
        ////   C r e a t e
        [HttpGet]
        public IActionResult Add()
            => View(new State());
        [HttpPost]
        public IActionResult Add(State state)
        {
            if (ModelState.IsValid)
            {
                _repository.CreateState(state);
                return RedirectToAction("Details", new {id = state.Id});
            }
            return View(state);
        } // Add method ends

        
        ////   R e a d
        public IActionResult Index()
            => View(_repository.GetAllStates());
        // Index method ends

        public IActionResult Details(int id)
        {
            State state = _repository.GetStateById(id);
            if (state != null)
            {
                return View(state);
            }
            return RedirectToAction("Index");
        } // Details method ends

        
        ////   U p d a t e
        [HttpGet]
        public IActionResult Edit(int id)
        {
            State state = _repository.GetStateById(id);
            if (state != null)
            {
                return View(state);
            }
            return RedirectToAction("Index");
        }
        [HttpPost]
        public IActionResult Edit(State state)
        {
            if (ModelState.IsValid)
            {
                _repository.UpdateState(state);
                return RedirectToAction("Details", new {id = state.Id});
            }
            return View(state);
        } // Edit method ends

        
        ////   D e l e t e
        [HttpGet]
        public IActionResult Delete(int id)
        {
            State state = _repository.GetStateById(id);
            if (state != null)
            {
                return View(state);
            }
            return RedirectToAction("Index");
        } // Delete HttpGet method ends
        [HttpPost]
        public IActionResult Delete(State state)
        {
            _repository.DeleteState(state.Id);
            return RedirectToAction("Index");
        } // Delete HttpPost method ends
    } // class ends
} // namespace ends
