﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace States.Migrations
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "States",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Population = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_States", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "States",
                columns: new[] { "Id", "Name", "Population" },
                values: new object[,]
                {
                    {  1, "Delaware", 990334 },
                    {  2, "Pennsylvania", 12804100 },
                    {  3, "New Jersey", 8874520 },
                    {  4, "Georgia", 10830000 },
                    {  5, "Connecticut", 3552820 },
                    {  6, "Massachusetts", 6912240 },
                    {  7, "Maryland", 6065440 },
                    {  8, "South Carolina", 5277830 },
                    {  9, "New Hampshire", 1372200 },
                    { 10, "Virginia", 8603980 },
                    { 11, "New York", 19300000 },
                    { 12, "North Carolina", 10701000 },
                    { 13, "Rhode Island", 1061510 },
                    { 14, "Vermont", 623251 },
                    { 15, "Kentucky", 4480710 },
                    { 16, "Tennessee", 6944260 },
                    { 17, "Ohio", 11714600 },
                    { 18, "Louisiana", 4627000 },
                    { 19, "Indiana", 6805660 },
                    { 20, "Mississippi", 2966410 },
                    { 21, "Illinois", 12569300 },
                    { 22, "Alabama", 4934190 },
                    { 23, "Maine", 1354520 },
                    { 24, "Missouri", 6169040 },
                    { 25, "Arkansas", 3033950 },
                    { 26, "Michigan", 9992430 },
                    { 27, "Florida", 21944600 },
                    { 28, "Texas", 29730300 },
                    { 29, "Iowa", 3167970 },
                    { 30, "Wisconsin", 5852490 },
                    { 31, "California", 39613500 },
                    { 32, "Minnesota", 5706400 },
                    { 33, "Oregon", 4289440 },
                    { 34, "Kansas", 2917220 },
                    { 35, "West Virginia", 1767860 },
                    { 36, "Nevada", 3185790 },
                    { 37, "Nebraska", 1952000 },
                    { 38, "Colorado", 5893630 },
                    { 39, "North Dakota", 770026 },
                    { 40, "South Dakota", 896581 },
                    { 41, "Montana", 1085000 },
                    { 42, "Washington", 7796940 },
                    { 43, "Idaho", 1860120 },
                    { 44, "Wyoming", 581075 },
                    { 45, "Utah", 3310770 },
                    { 46, "Oklahoma", 3990440 },
                    { 47, "New Mexico", 2105000 },
                    { 48, "Arizona", 7520100 },
                    { 49, "Alaska", 724357 },
                    { 50, "Hawaii", 1406430 }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "States");
        }
    }
}
