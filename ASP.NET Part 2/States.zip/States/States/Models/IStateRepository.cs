﻿using System.Linq;

namespace States.Models
{
    public interface IStateRepository
    {
        // create
        public State CreateState(State state);
        
        
        // read
        public IQueryable<State> GetAllStates();

        public State GetStateById(int stateId);
        
        
        // update
        public State UpdateState(State state);    
        
        // delete
        public bool DeleteState(int stateId);
    } // class ends
} // namespace ends