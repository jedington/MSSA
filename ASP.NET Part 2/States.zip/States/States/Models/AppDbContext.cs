﻿using Microsoft.EntityFrameworkCore;

namespace States.Models
{
   public class AppDbContext
      : DbContext
   {
      //   F i e l d s   &   P r o p e r t i e s

      public DbSet<State> States { get; set; }


      //   C o n s t r u c t o r s

      public AppDbContext(DbContextOptions<AppDbContext> options)
         : base(options)
      {
      }


      //   M e t h o d s

      protected override void OnModelCreating(ModelBuilder modelBuilder)
      {
         base.OnModelCreating(modelBuilder);

         modelBuilder.Entity<State>().HasData(new State { Id =  1, Name = "Delaware"      , Population =    990_334 });
         modelBuilder.Entity<State>().HasData(new State { Id =  2, Name = "Pennsylvania"  , Population = 12_804_100 });
         modelBuilder.Entity<State>().HasData(new State { Id =  3, Name = "New Jersey"    , Population =  8_874_520 });
         modelBuilder.Entity<State>().HasData(new State { Id =  4, Name = "Georgia"       , Population = 10_830_000 });
         modelBuilder.Entity<State>().HasData(new State { Id =  5, Name = "Connecticut"   , Population =  3_552_820 });
         modelBuilder.Entity<State>().HasData(new State { Id =  6, Name = "Massachusetts" , Population =  6_912_240 });
         modelBuilder.Entity<State>().HasData(new State { Id =  7, Name = "Maryland"      , Population =  6_065_440 });
         modelBuilder.Entity<State>().HasData(new State { Id =  8, Name = "South Carolina", Population =  5_277_830 });
         modelBuilder.Entity<State>().HasData(new State { Id =  9, Name = "New Hampshire" , Population =  1_372_200 });
         modelBuilder.Entity<State>().HasData(new State { Id = 10, Name = "Virginia"      , Population =  8_603_980 });
         modelBuilder.Entity<State>().HasData(new State { Id = 11, Name = "New York"      , Population = 19_300_000 });
         modelBuilder.Entity<State>().HasData(new State { Id = 12, Name = "North Carolina", Population = 10_701_000 });
         modelBuilder.Entity<State>().HasData(new State { Id = 13, Name = "Rhode Island"  , Population =  1_061_510 });
         modelBuilder.Entity<State>().HasData(new State { Id = 14, Name = "Vermont"       , Population =    623_251 });
         modelBuilder.Entity<State>().HasData(new State { Id = 15, Name = "Kentucky"      , Population =  4_480_710 });
         modelBuilder.Entity<State>().HasData(new State { Id = 16, Name = "Tennessee"     , Population =  6_944_260 });
         modelBuilder.Entity<State>().HasData(new State { Id = 17, Name = "Ohio"          , Population = 11_714_600 });
         modelBuilder.Entity<State>().HasData(new State { Id = 18, Name = "Louisiana"     , Population =  4_627_000 });
         modelBuilder.Entity<State>().HasData(new State { Id = 19, Name = "Indiana"       , Population =  6_805_660 });
         modelBuilder.Entity<State>().HasData(new State { Id = 20, Name = "Mississippi"   , Population =  2_966_410 });
         modelBuilder.Entity<State>().HasData(new State { Id = 21, Name = "Illinois"      , Population = 12_569_300 });
         modelBuilder.Entity<State>().HasData(new State { Id = 22, Name = "Alabama"       , Population =  4_934_190 });
         modelBuilder.Entity<State>().HasData(new State { Id = 23, Name = "Maine"         , Population =  1_354_520 });
         modelBuilder.Entity<State>().HasData(new State { Id = 24, Name = "Missouri"      , Population =  6_169_040 });
         modelBuilder.Entity<State>().HasData(new State { Id = 25, Name = "Arkansas"      , Population =  3_033_950 });
         modelBuilder.Entity<State>().HasData(new State { Id = 26, Name = "Michigan"      , Population =  9_992_430 });
         modelBuilder.Entity<State>().HasData(new State { Id = 27, Name = "Florida"       , Population = 21_944_600 });
         modelBuilder.Entity<State>().HasData(new State { Id = 28, Name = "Texas"         , Population = 29_730_300 });
         modelBuilder.Entity<State>().HasData(new State { Id = 29, Name = "Iowa"          , Population =  3_167_970 });
         modelBuilder.Entity<State>().HasData(new State { Id = 30, Name = "Wisconsin"     , Population =  5_852_490 });
         modelBuilder.Entity<State>().HasData(new State { Id = 31, Name = "California"    , Population = 39_613_500 });
         modelBuilder.Entity<State>().HasData(new State { Id = 32, Name = "Minnesota"     , Population =  5_706_400 });
         modelBuilder.Entity<State>().HasData(new State { Id = 33, Name = "Oregon"        , Population =  4_289_440 });
         modelBuilder.Entity<State>().HasData(new State { Id = 34, Name = "Kansas"        , Population =  2_917_220 });
         modelBuilder.Entity<State>().HasData(new State { Id = 35, Name = "West Virginia" , Population =  1_767_860 });
         modelBuilder.Entity<State>().HasData(new State { Id = 36, Name = "Nevada"        , Population =  3_185_790 });
         modelBuilder.Entity<State>().HasData(new State { Id = 37, Name = "Nebraska"      , Population =  1_952_000 });
         modelBuilder.Entity<State>().HasData(new State { Id = 38, Name = "Colorado"      , Population =  5_893_630 });
         modelBuilder.Entity<State>().HasData(new State { Id = 39, Name = "North Dakota"  , Population =    770_026 });
         modelBuilder.Entity<State>().HasData(new State { Id = 40, Name = "South Dakota"  , Population =    896_581 });
         modelBuilder.Entity<State>().HasData(new State { Id = 41, Name = "Montana"       , Population =  1_085_000 });
         modelBuilder.Entity<State>().HasData(new State { Id = 42, Name = "Washington"    , Population =  7_796_940 });
         modelBuilder.Entity<State>().HasData(new State { Id = 43, Name = "Idaho"         , Population =  1_860_120 });
         modelBuilder.Entity<State>().HasData(new State { Id = 44, Name = "Wyoming"       , Population =    581_075 });
         modelBuilder.Entity<State>().HasData(new State { Id = 45, Name = "Utah"          , Population =  3_310_770 });
         modelBuilder.Entity<State>().HasData(new State { Id = 46, Name = "Oklahoma"      , Population =  3_990_440 });
         modelBuilder.Entity<State>().HasData(new State { Id = 47, Name = "New Mexico"    , Population =  2_105_000 });
         modelBuilder.Entity<State>().HasData(new State { Id = 48, Name = "Arizona"       , Population =  7_520_100 });
         modelBuilder.Entity<State>().HasData(new State { Id = 49, Name = "Alaska"        , Population =    724_357 });
         modelBuilder.Entity<State>().HasData(new State { Id = 50, Name = "Hawaii"        , Population =  1_406_430 });
      }
   }
}
