﻿using System.Linq;

namespace States.Models
{
    public class EfStateRepository : IStateRepository
    {
        //   F i e l d s   &   P r o p e r t i e s
        private AppDbContext _context;
      
        //   C o n s t r u c t o r s
        public EfStateRepository(AppDbContext context)
            => _context = context;
        // EfStateRepository const ends


        // methods
        //// create
        public State CreateState(State state)
        {
            _context.States.Add(state);
            _context.SaveChanges();
            return state;
        } // CreateState method ends
        
        
        //// read
        public IQueryable<State> GetAllStates()
            => _context.States;
        // GetAllStates method ends

        public State GetStateById(int stateId)
            => _context.States.Find(stateId);
        // GetStateById method ends
        
        
        //// update
        public State UpdateState(State state)
        {
            State stateToUpdate = _context.States.Find(state.Id);
            if (stateToUpdate != null)
            {
                stateToUpdate.Name = state.Name;
                stateToUpdate.Population = state.Population;
                _context.SaveChanges();
            }
            return stateToUpdate;
        } // UpdateState method ends
        

        //// delete
        public bool DeleteState(int stateId)
        {
            State stateToDelete = GetStateById(stateId);
            if (stateToDelete == null)
            {
                return false;
            }
            _context.States.Remove(stateToDelete);
            _context.SaveChanges();
            return true;
        } // DeleteState method ends
    } // class ends
} // namespace ends