﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Mvc;

namespace States.Models
{
    public class State
    {
        //   F i e l d s   &   P r o p e r t i e s
        [HiddenInput(DisplayValue = false)]
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int    Id         { get; set; }
        public string Name       { get; set; }
        public int    Population { get; set; }
        
        
        //   C o n s t r u c t o r s
        
        
        //   M e t h o d s
        
    }
}
