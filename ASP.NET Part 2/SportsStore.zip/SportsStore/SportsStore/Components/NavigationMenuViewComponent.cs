﻿using Microsoft.AspNetCore.Mvc;
using SportsStore.Models;

namespace SportsStore.Components
{
    public class NavigationMenuViewComponent : ViewComponent
    {
        // fields
        private IProductRepository _repository;


        // constructors
        public NavigationMenuViewComponent(IProductRepository repository)
            => _repository = repository;
        // NavigationMenuViewComponent const ends


        // methods
        public IViewComponentResult Invoke()
        {
            ViewBag.SelectedCategory = RouteData?.Values["category"];
            return View(_repository.GetAllCategories());
        } 
        // Invoke method ends
    } // class ends
} // namespace ends