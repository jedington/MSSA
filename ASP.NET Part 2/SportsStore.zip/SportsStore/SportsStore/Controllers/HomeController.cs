﻿using System.Linq;
using Microsoft.AspNetCore.Mvc;
using SportsStore.Models;

namespace SportsStore.Controllers
{
    public class HomeController : Controller
    {
        // fields
        private int _pageSize = 3;
        private IProductRepository _repository;


        // constructors
        public HomeController(IProductRepository repository)
            => _repository = repository;
        // HomeController const ends
        

        // methods


        //// create
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Add(Product p)
        {
            _repository.Create(p);
            return RedirectToAction("Index");
        }


        //// read
        public IActionResult Index(string category, int productPage = 1)
        {
            IQueryable<Product> allProducts = _repository
                .GetAllProducts()
                .OrderByDescending(p => p.Price);
            IQueryable<Product> someProducts;
            if (category == null)
            {
                someProducts = allProducts
                    .OrderBy(p => p.ProductId)
                    .Skip((productPage - 1) * _pageSize)
                    .Take(_pageSize);
            }
            else
            {
                someProducts = allProducts
                    .OrderBy(p => p.ProductId)
                    .Where(p => p.Category == category)
                    .Skip((productPage - 1) * _pageSize)
                    .Take(_pageSize);
            }

            PagingInfo pi = new PagingInfo
            {
                TotalItems = allProducts.Count(),
                ItemsPerPage = _pageSize,
                CurrentPage = productPage
            };

            ProductListViewModel plvm = new ProductListViewModel
            {
                Products = someProducts,
                PagingInfo = pi,
                CurrentCategory = category
            };

            //- ViewBag.Paging = pi;
            //- ViewBag.ProductCount = allProducts.Count();
            return View(plvm);
        } // Index method ends

        //- public IActionResult Index2()
        //- {
        //-     IQueryable<Product> allProducts = _repository
        //-         .GetAllProducts();
        //-     IQueryable<Product> someProducts = allProducts
        //-         .OrderByDescending(p => p.Price)
        //-         .Where(p => p.Price >= 50);
        //- 
        //-     var catProducts = allProducts
        //-         .GroupBy(p => p.Category);
        //-     foreach (var category in catProducts)
        //-     {
        //-         var x = category.Key;
        //-         var y = category.Count();
        //-     }
        //-     
        //-     return View(someProducts);
        //- }

        public IActionResult Categories()
        {
            IQueryable<string> categories = _repository
                .GetAllCategories();
            IQueryable<string> lengthCategories = categories
                .OrderBy(s => s.Length)
                .ThenByDescending(s => s);
            return View(lengthCategories);
        } // Details method ends

        public IActionResult Details(int productId)
        {
            Product p = _repository.GetProductById(productId);
            if (p != null)
            {
                return View(p);
            }
            return RedirectToAction("Index");
        } // Details method ends

        public IActionResult Search(string keyword)
        {
            IQueryable<Product> productsWithKeyword = _repository
                .GetProductsByKeyword(keyword);
            ViewBag.Search = keyword;
            //- ViewBag.Bar = "Hello World";
            //- ViewBag.FooBar = 3.14159;
            //- ViewBag.Honest = true;
            return View(productsWithKeyword);
        } // Search method ends


        //// update
        [HttpGet]
        public IActionResult Update(int productId)
        {
            Product p = _repository.GetProductById(productId);
            if (p != null)
            {
                return View(p);
            }
            return RedirectToAction("Index");
        } // Update HttpGet method ends
        [HttpPost]
        public IActionResult Update(Product p)
        {
            Product updatedProduct = _repository.UpdateProduct(p);
            return RedirectToAction("Index", new { productId = p.ProductId } );
        } // Update HttpPost method ends


        //// delete
        [HttpGet]
        public IActionResult Delete(int id)
        {
            Product p = _repository.GetProductById(id);
            if (p != null)
            {
                return View(p);
            }
            return RedirectToAction("Index");
        } // Delete HttpGet method ends
        [HttpPost]
        public IActionResult DeleteAction(int id)
        {
            _repository.DeleteProduct(id);
            return RedirectToAction("Index");
        } // Delete HttpPost method ends


    } // class ends
} // namespace ends