﻿using System.Linq;

namespace SportsStore.Models
{
    public interface IProductRepository
    {
        // create
        public Product Create(Product p);

        // read
        public IQueryable<Product> GetAllProducts();

        public IQueryable<string> GetAllCategories();

        public Product GetProductById(int productId);

        public IQueryable<Product> GetProductsByKeyword(string keyword);


        // update
        public Product UpdateProduct(Product p);


        // delete
        public bool DeleteProduct(int id);


    } // class ends
} // namespace ends
