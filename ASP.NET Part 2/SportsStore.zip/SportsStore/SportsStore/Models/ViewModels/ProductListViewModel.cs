﻿using System.Linq;

namespace SportsStore.Models
{
    public class ProductListViewModel // Data Transfer Object -- DTO
    {
        //   fields and properties
        public IQueryable<Product> Products { get; set; }
 
        public PagingInfo PagingInfo { get; set; }

        public string CurrentCategory { get; set; }

        //   constructors

        //   methods

    } // class ends
} // namespace ends