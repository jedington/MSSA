using System.Linq;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SportsStore.Infrastructure;
using SportsStore.Models;
 
namespace SportsStore.Pages
{
    public class CartModel
        : PageModel
    {
        //   F i e l d s   &   P r o p e r t i e s
 
        private IProductRepository _repository;
 
        public  Cart               Cart      { get; set; }
        public  string             ReturnUrl { get; set; }
 
        //   C o n s t r u c t o r s
 
        public CartModel(IProductRepository repository)
        {
            _repository = repository;
        }
 
        //   M e t h o d s
 
        public void OnGet(string returnUrl = "/")
        {
            ReturnUrl = returnUrl;
 
            Cart = HttpContext.Session.GetJson<Cart>("cart");
            if (Cart == null)
            {
                Cart = new Cart();
            }
        }
 
        public void OnPost(int    productId,
            string returnUrl = "/")
        {
            ReturnUrl = returnUrl;
 
            Cart = HttpContext.Session.GetJson<Cart>("cart");
            if (Cart == null)
            {
                Cart = new Cart();
            }
 
            Product product = _repository.GetAllProducts()
                .FirstOrDefault(p => p.ProductId == productId);
            if (product != null)
            {
                Cart.AddItem(product, 1);
            }
 
            HttpContext.Session.SetJson("cart", Cart);
        }
    }
}

