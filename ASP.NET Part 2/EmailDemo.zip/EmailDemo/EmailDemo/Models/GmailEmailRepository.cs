﻿using System;
using System.Net;
using System.Net.Mail;

namespace EmailDemo.Models
{
    public class GmailEmailRepository : IEmailRepository
    {
        public void Send(string to, string subject, string body)
        {
            string emailAccount = System.Environment.GetEnvironmentVariable("VisionBoardEmailAccount");
            string emailPassword = System.Environment.GetEnvironmentVariable("VisionBoardEmailAccount");

            try
            {
                MailMessage email = new MailMessage();
                email.From = new MailAddress(emailAccount);
                email.To.Add(to);
                email.Bcc.Add(emailAccount);
                email.Subject = subject;
                email.Body = body;
                email.IsBodyHtml = true;

                SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587);
                smtp.Credentials = new NetworkCredential
                    (emailAccount, emailPassword);
                smtp.EnableSsl = true;
                smtp.Send(email);

            }
            catch (Exception e)
            {
                // look at what is in 'e'
            }
        }
    }
}