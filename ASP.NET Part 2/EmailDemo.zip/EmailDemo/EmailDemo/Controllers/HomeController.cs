﻿using EmailDemo.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace EmailDemo.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private IEmailRepository _emailRepo;

        public HomeController(ILogger<HomeController> logger, IEmailRepository emailRepo)
        {
            _logger = logger;
            _emailRepo = emailRepo;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult TestEmail()
        {
            _emailRepo.Send("julianedington@gmail.com", "Testing C# Email", "Wow, it works!");
            return RedirectToAction("Index");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
