﻿using System.Linq;

namespace Foo.Models
{
   public interface IUserRepository
   {
      public IQueryable<User> GetAllUsers();
   }
}
