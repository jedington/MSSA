﻿using System.Linq;

namespace Foo.Models
{
    public class EfUserRepository : IUserRepository
    {
        // properties
        private AppDbContext _context;

        // constructor
        public EfUserRepository(AppDbContext context)
        {
            _context = context;
        }
        
        public IQueryable<User> GetAllUsers()
        {
            return _context.Users;
        }
    }
}
