﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Foo.Models
{
    [Table("User")]
    public class User
   {
      //   F i e l d s   &   P r o p e r t i e s

      public int    UserId       { get; set; }

      public string UserName { get; set; }

      public string Password { get; set; }


      //   C o n s t r u c t o r s


      //   M e t h o d s

   }
}
