﻿using Microsoft.EntityFrameworkCore;

namespace Foo.Models
{
    public class AppDbContext : DbContext
    {
        // properties
        public DbSet<User> Users { get; set; }

        // constructors
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        } // AppDbContext const ends

        // methods
        protected override void OnModelCreating 
            (ModelBuilder modelBuilder)
        { 
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<User>().HasData
                (new User
                {​​​​​
                    UserId = 1, 
                    UserName = "BantaP@ERAU.Edu",    
                    Password = "Wombat1"
                }​​​​​);

                modelBuilder.Entity<User>().HasData
                (new User
                {
                    UserId = 2, 
                    UserName = "BantaP@Example.Com", 
                    Password = "Wombat2"
                }​​​​​);
        }​​​​​ // OnModelCreating method ends
    } // class ends
} // namespace ends