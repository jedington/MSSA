﻿using Foo.Models;
using Microsoft.AspNetCore.Mvc;

namespace Foo.Controllers
{
   public class HomeController : Controller
   {
      //   F i e l d s   &   P r o p e r t i e s

      private IUserRepository _repository;


      //   C o n s t r u c t o r s

      public HomeController(IUserRepository repository)
      {
         _repository = repository;
      }


      //   M e t h o d s

      public IActionResult Index()
      {
         return View(_repository.GetAllUsers());
      }
   }
}
