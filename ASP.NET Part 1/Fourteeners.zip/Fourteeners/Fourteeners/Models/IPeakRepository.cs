﻿using System.Linq;

namespace Fourteeners.Models
{
    public interface IPeakRepository
    {
        public IQueryable<Peak> GetAllPeaks();


    }
}