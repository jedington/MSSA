﻿
using System.Linq;

namespace Fourteeners.Models
{
    internal class FakePeakRepository : IPeakRepository
    {
        public IQueryable<Peak> GetAllPeaks()
        {
            Peak[] peaks = new Peak[2];

            peaks[0] = new Peak
            {
                Id = 1,
                Name = "Pikes Peak",
                Elevation = 14110
            };

            peaks[1] = new Peak
            {
                Id = 2,
                Name = "Grays Peak",
                Elevation = 14270
            };
            return peaks.AsQueryable<Peak>();
        }
    }
}