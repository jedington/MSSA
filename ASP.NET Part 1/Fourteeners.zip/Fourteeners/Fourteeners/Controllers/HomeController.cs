﻿using Fourteeners.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace Fourteeners.Controllers
{
    public class HomeController 
        : Controller
    {
        private IPeakRepository _repository;

        public HomeController(IPeakRepository repository)
        {
            _repository = repository;
        }

        public IActionResult Index()
        {
            IQueryable<Peak> allPeaks = _repository.GetAllPeaks();
            return View(allPeaks);
        }
    }
}
