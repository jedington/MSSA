﻿using ASPCh3.Forms.Models;
using Microsoft.AspNetCore.Mvc;

namespace ASPCh3.Forms.Controllers
{
    public class UserController : Controller
    {
        [HttpGet]
        public IActionResult Add()
        {
            IActionResult view = View();
            return view;
        }
        [HttpPost]
        public IActionResult Add(User submit)
        {
            if (ModelState.IsValid)
            {
                return View("Details", submit);
            }
            return View(submit);
        }

        [HttpGet]
        public IActionResult Details()
        {
            IActionResult view = View();
            return view;
        }
        [HttpPost]
        public IActionResult Details(User submit)
        {
            if (ModelState.IsValid)
            {
                return View("Edit", submit);
            }
            return View(submit);
        }

        [HttpGet]
        public IActionResult Edit()
        {
            IActionResult view = View();
            return view;
        }
        [HttpPost]
        public IActionResult Edit(User submit)
        {
            if (ModelState.IsValid)
            {
                return View("Details", submit);
            }
            return View(submit);
        }
    }
}
