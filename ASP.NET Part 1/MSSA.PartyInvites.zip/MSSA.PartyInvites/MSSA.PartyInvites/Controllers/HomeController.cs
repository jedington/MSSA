﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using MSSA.PartyInvites.Models;

namespace MSSA.PartyInvites.Controllers
{
    public class HomeController : Controller
    {
        // fields


        // constructors


        // methods
        public IActionResult Index()
        {
            // GuestResponse someResponse = new GuestResponse();
            // someResponse.Name = "Julian"; // set
            // string t = someResponse.Name; // get
            // someResponse.Email = "julian@example.com"; // set
            // string e = someResponse.Email; // get
            return View();
        }

        public IActionResult ListResponses()
        {
            List<GuestResponse> responses = Repository.GetResponses();
            List<GuestResponse> willAttend // LInQ - Language Integrated Query
                = responses.Where(r => r.WillAttend == true).ToList();
            return View(responses);
        }

        [HttpGet]
        public IActionResult RsvpForm()
        {
            IActionResult answer = View();
            return answer;
        }

        [HttpPost]
        public IActionResult RsvpForm(GuestResponse gResponse)
        {
            if (ModelState.IsValid)
            {
                Repository.AddResponse(gResponse);
                return View("Thanks", gResponse); // Thanks.cshtml
            }
            else
            {
                return View(gResponse);
            }
        }
    } // class ends
} // namespace ends
