﻿using System.Collections.Generic;

namespace MSSA.PartyInvites.Models
{
    public class Repository
    {
        // fields & properties
        private static List<GuestResponse> responses = new List<GuestResponse>();
 
        // Constructors
        // Methods
 
        public static void AddResponse(GuestResponse response)
            => responses.Add(response);
        
        public static List<GuestResponse> GetResponses()
            => responses;
    } // class ends
} // namespace ends