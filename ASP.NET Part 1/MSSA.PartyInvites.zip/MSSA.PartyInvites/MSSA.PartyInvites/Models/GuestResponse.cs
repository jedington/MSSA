﻿using System.ComponentModel.DataAnnotations;

namespace MSSA.PartyInvites.Models
{
    public class GuestResponse
    {
        // fields & properties

        [Required(ErrorMessage = "A Name Is Required")]
        public string Name { get; set; } // Email property ends (102)
            // {
            //     get
            //     {
            //         return Name;
            //     }
            //     set
            //     {
            //         if (value != null && value != "")
            //         {
            //             Name = value;
            //         }
            //     }
            // } // Name property ends (101)

        [Required(ErrorMessage = "An Email is Required")]
        [EmailAddress]
        public string Email { get; set; } // Email property ends (102)

        [Required(ErrorMessage = "A Phone Number is Required")]
        public string Phone { get; set; } // Phone property ends (102)

        [Required(ErrorMessage = "Response is Required")]
        public bool?  WillAttend { get; set; } // WillAttend property ends (102)

        // constructors

        // methods

    } // class ends
} // namespace ends
