﻿using Microsoft.AspNetCore.Mvc;
using IceCream.Models;
using System.Linq;

namespace IceCream.Controllers
{
    public class HomeController : Controller
    {
        private IIceCreamRepository _repository;

        public HomeController (IIceCreamRepository repository)
        {
            _repository = repository;
        } // HomeController const ends

        public IActionResult Index()
        {
            IQueryable<Models.IceCream> allIceCreams = _repository.GetAllIceCreams();
            return View(allIceCreams);
        } // Index method ends
    } // class ends
} // namespace ends
