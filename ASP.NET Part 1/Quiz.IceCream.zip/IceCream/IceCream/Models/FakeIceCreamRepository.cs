﻿using System.Linq;

namespace IceCream.Models
{
    public class FakeIceCreamRepository : IIceCreamRepository
    {
        public IQueryable<IceCream> GetAllIceCreams()
        {
            IceCream[] iceCream = new IceCream[3];

            iceCream[0] = new IceCream
            {
                Id = 1,
                Flavor = "Chocolate",
            };
            iceCream[1] = new IceCream
            {
                Id = 2,
                Flavor = "Vanilla",
            };
            iceCream[2] = new IceCream
            {
                Id = 3,
                Flavor = "Strawberry",
            };
            return iceCream.AsQueryable<IceCream>();
        } // GetAllIceCreams ends
    } // class ends
} // namespace ends