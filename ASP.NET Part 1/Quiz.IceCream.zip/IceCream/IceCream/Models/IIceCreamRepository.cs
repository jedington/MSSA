﻿using System.Linq;

namespace IceCream.Models
{
    public interface IIceCreamRepository
    {
        public IQueryable<IceCream> GetAllIceCreams();
    } // class ends
} // namespace ends