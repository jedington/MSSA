﻿namespace IceCream.Models
{
    public class IceCream
    {
        public int    Id     { get; set; }
        public string Flavor { get; set; }
    } // class ends
} // namespace ends
