﻿using System.Linq;

namespace SportsStore.Models
{
    public class EfProductRepository : IProductRepository
    {
        // fields
        private AppDbContext _context;


        // constructors
        public EfProductRepository(AppDbContext context)
            => _context = context;
        // EfProductRepository const ends


        // methods
        //// create
        public Product Create(Product p)
        {
            _context.Products.Add(p);
            _context.SaveChanges();
            return p;
        }
        
        //// read
        public IQueryable<Product> GetAllProducts()
            => _context.Products; // F-Magic
        // GetAllProducts method ends

        public IQueryable<string> GetAllCategories()
            => _context.Products.Select(p => p.Category)
                                .Distinct();

        public Product GetProductById(int productId)
            //- Product p = _context.Products
            //-     .Where(p => p.ProductId == productId).FirstOrDefault();
            => _context.Products.Find(productId);
         // GetProductById method ends

        public IQueryable<Product> GetProductsByKeyword(string keyword)
            //- IQueryable<Product> products = _context.Products
            //-     .Where(p => p.Name.Contains(keyword));
            => _context.Products.Where(p => p.Name.Contains(keyword));
        // GetProductsByKeyword method ends

        //// update
        public Product UpdateProduct(Product p)
        {
            Product productToUpdate = _context.Products.Find(p.ProductId);
            if (productToUpdate != null)
            {
                productToUpdate.Category = p.Category;
                productToUpdate.Description = p.Description;
                productToUpdate.Name = p.Name;
                productToUpdate.Price = p.Price;
                _context.SaveChanges();
            }
            return productToUpdate;
        } // UpdateProduct method ends


        //// delete
        public bool DeleteProduct(int id)
        {
            // Product productToDelete = _context.Products.Find(id);
            Product productToDelete = GetProductById(id);
            if (productToDelete == null)
            {
                return false;
            }
            _context.Products.Remove(productToDelete);
            _context.SaveChanges();
            return true;
        } // DeleteProduct method ends

    } // class ends
} // namespace ends