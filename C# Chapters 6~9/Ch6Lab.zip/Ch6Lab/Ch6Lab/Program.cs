﻿using System;

namespace Ch6Lab
{
    public class Program
    {
        public static void Main(string[] args)
        {
            RunDouble("Input a value (decimals allowed): ");
            RunInt("Input another value (no decimals): ");
        } // Main method ends

        static double RunDouble(string doublePull)
        {
            double inputDouble = 0;
            bool checkInput = false;
            while (checkInput == false)
            {
                try
                {
                    Console.Write(doublePull);
                    inputDouble = Convert.ToDouble(Console.ReadLine());
                    //  if (inputDouble == Math.Abs(inputDouble))
                    //  {
                    checkInput = true;
                    Console.WriteLine("Good user input, output value is a valid 'double'");
                    //  }
                }
                catch (FormatException fe)
                {
                    Console.WriteLine($"...Please enter a real value. \n{fe.Message}");
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
            return inputDouble;
        } // InputDouble method ends

        static int RunInt(string intPull)
        {
            int inputInt = 0;
            bool checkInput = false;
            while (checkInput == false)
            {
                try
                {
                    Console.Write(intPull);
                    inputInt = Convert.ToInt32(Console.ReadLine());
                    checkInput = true;
                    Console.WriteLine("Good user input, output value is a valid 'int'");
                }
                catch (FormatException fe)
                {
                    Console.WriteLine($"...Please enter a real value. \n{fe.Message}");
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
            return inputInt;
        } // InputInt method ends
    } // class ends
} // namespace ends
