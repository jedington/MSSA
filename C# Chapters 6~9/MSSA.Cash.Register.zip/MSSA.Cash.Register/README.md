# MSSA.Cash.Register
MSSA Labs/Exercises progressively towards creating a Cash Register through .NET core console.
