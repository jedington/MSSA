using Xunit;
using Ch17Lab.Stack;

namespace StackTest
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            IntStack x = new IntStack(3);
            x.Push(1);
            x.Push(2);
            Assert.Equal(false, x.IsEmpty());
            Assert.Equal(2, x.Pop());
        }
    }
}
